import { useRef, useState } from 'react';
import {
  CloudUpload,
  X,
  Volume2,
  Users,
  Sparkles,
  LoaderCircle,
  CircleCheck,
  TriangleAlert,
} from 'lucide-react';
import { usePipeline, PIPELINE_STEPS, type LogKind } from '../hooks/usePipeline';

const LANGS = [
  { v: 'auto', l: 'خۆکار (Auto Detect Language) ✦' },
  { v: 'en', l: 'ئینگلیزی (English)' },
  { v: 'ar', l: 'عەرەبی (Arabic)' },
  { v: 'fa', l: 'فارسی (Persian)' },
  { v: 'tr', l: 'تورکی (Turkish)' },
  { v: 'de', l: 'ئەڵمانی (German)' },
  { v: 'ku', l: 'کوردی سۆرانی (تەنها نووسینەوە و ڕێکخستنی کات)' },
];

function logColor(kind: LogKind) {
  if (kind === 'err') return 'text-rose-400';
  if (kind === 'ok') return 'text-emerald-300';
  if (kind === 'warn') return 'text-amber-300';
  if (kind === 'model') return 'text-sky-300';
  return 'text-emerald-400/90';
}

type Props = {
  open: boolean;
  onClose: () => void;
  onComplete: (project: Record<string, unknown>) => void;
};

export default function UploadModal({ open, onClose, onComplete }: Props) {
  const [file, setFile] = useState<File | null>(null);
  const [sourceLang, setSourceLang] = useState('auto');
  const [cleanupAudio, setCleanupAudio] = useState(true);
  const [diarization, setDiarization] = useState(true);
  const fileRef = useRef<HTMLInputElement>(null);
  const logRef = useRef<HTMLDivElement>(null);
  const pipe = usePipeline();

  if (!open) return null;

  const pick = (f?: File | null) => {
    if (f) {
      setFile(f);
      pipe.reset();
    }
  };

  const start = () => {
    if (!file || pipe.active) return;
    logRef.current?.scrollTo(0, 0);
    pipe.run({
      file,
      title: file.name.replace(/\.[^.]+$/, ''),
      sourceLang,
      cleanupAudio,
      diarization,
      onDone: (p) => onComplete(p),
    });
  };

  const close = () => {
    if (pipe.active) {
      if (!confirm('Processing is running. Cancel it and close?')) return;
      pipe.cancel();
    }
    setFile(null);
    pipe.reset();
    onClose();
  };

  const bi = (ckb: string, en: string) => (
    <span>
      <span className="font-kurdish">{ckb}</span>
      <span className="block text-[10px] font-normal text-slate-500 font-sans">{en}</span>
    </span>
  );

  const stepIdx = PIPELINE_STEPS.findIndex((s) => s.key === pipe.stage);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#131b2a] border border-[#1f293d] w-full max-w-2xl rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-[#1f293d] pb-4">
          <div>
            <h3 className="text-xl font-bold text-white flex items-center gap-2">
              <CloudUpload className="w-5 h-5 text-emerald-400" />
              بارکردنی ڤیدیۆ و دروستکردنی ژێرنووس
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Real pipeline: decode → Whisper STT → Sorani MT → SRT. Progress = completed work.
            </p>
          </div>
          <button
            onClick={close}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-[#0b0f17] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {!pipe.active && pipe.stage !== 'done' && pipe.stage !== 'error' && (
          <div className="space-y-5">
            <div
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                pick(e.dataTransfer.files?.[0]);
              }}
              className="border-2 border-dashed border-[#1f293d] hover:border-emerald-500/60 rounded-2xl p-8 text-center cursor-pointer bg-[#0b0f17]/50 hover:bg-emerald-500/5 transition-all group"
            >
              <input
                ref={fileRef}
                type="file"
                accept="video/mp4,video/quicktime,video/x-matroska,video/webm,audio/mp3,audio/wav,audio/mpeg,audio/mp4,audio/ogg,audio/webm"
                className="hidden"
                onChange={(e) => pick(e.target.files?.[0])}
              />
              <div className="w-14 h-14 mx-auto rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform mb-3">
                <CloudUpload className="w-7 h-7" />
              </div>
              <div className="text-sm font-bold text-white">
                {file ? (
                  <span className="text-emerald-400">{file.name}</span>
                ) : (
                  'فایلی ڤیدیۆکەت لێرە دابنێ یان کرتە بکە بۆ هەڵبژاردن'
                )}
              </div>
              {file && (
                <p className="text-xs text-slate-400 mt-1">
                  قەبارە: {(file.size / 1048576).toFixed(2)} MB
                </p>
              )}
              <p className="text-xs text-slate-400 mt-1">
                MP4, MKV, MOV, WEBM, MP3, WAV (up to 500MB, 20 min)
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">زمانی سەرەکی ڤیدیۆکە</label>
                <select
                  value={sourceLang}
                  onChange={(e) => setSourceLang(e.target.value)}
                  className="w-full bg-[#0b0f17] border border-[#1f293d] text-slate-200 text-xs rounded-xl p-3 outline-none focus:border-emerald-500"
                >
                  {LANGS.map((l) => (
                    <option key={l.v} value={l.v}>
                      {l.l}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300">شێوەزاری ژێرنووس</label>
                <select className="w-full bg-[#0b0f17] border border-[#1f293d] text-emerald-400 font-bold text-xs rounded-xl p-3 outline-none">
                  <option>کوردیی سۆرانی ستاندارد (ڕێزمانی ئەکادیمی)</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-[#0b0f17] border border-[#1f293d] rounded-xl space-y-2.5 text-xs text-slate-300">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-emerald-400" /> Peak-normalize + enhance audio for
                  cleaner recognition
                </span>
                <input
                  type="checkbox"
                  checked={cleanupAudio}
                  onChange={(e) => setCleanupAudio(e.target.checked)}
                  className="w-4 h-4 rounded accent-emerald-500"
                />
              </label>
              <label className="flex items-center justify-between cursor-pointer">
                <span className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" /> Alternate speakers on detected speech
                  turns
                </span>
                <input
                  type="checkbox"
                  checked={diarization}
                  onChange={(e) => setDiarization(e.target.checked)}
                  className="w-4 h-4 rounded accent-emerald-500"
                />
              </label>
            </div>

            <button
              onClick={start}
              disabled={!file}
              className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 text-white font-bold text-sm rounded-xl transition shadow-lg flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" /> دەستپێکردنی پرۆسەی ژێرنووسکردن بە AI
            </button>
            <p className="text-[11px] text-slate-500 text-center">
              First run downloads Whisper Base (~150MB, cached afterwards). Your video never leaves
              this device except for text translation + subtitle storage.
            </p>
          </div>
        )}

        {(pipe.active || pipe.stage === 'done' || pipe.stage === 'error') && (
          <div className="space-y-5">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold mb-2">
                <span className="text-slate-300 flex items-center gap-2">
                  {pipe.stage === 'done' ? (
                    <CircleCheck className="w-4 h-4 text-emerald-400" />
                  ) : pipe.stage === 'error' ? (
                    <TriangleAlert className="w-4 h-4 text-rose-400" />
                  ) : (
                    <LoaderCircle className="w-4 h-4 text-emerald-400 animate-spin" />
                  )}
                  {pipe.stage === 'done'
                    ? 'تەواوبوو'
                    : pipe.stage === 'error'
                      ? 'هەڵە'
                      : PIPELINE_STEPS.find((s) => s.key === pipe.stage)?.ckb || '…'}
                </span>
                <span className="font-mono text-emerald-400">{pipe.progress}%</span>
              </div>
              <div className="h-2.5 rounded-full bg-[#0b0f17] overflow-hidden border border-[#1f293d]">
                <div
                  className={`h-full transition-all duration-500 ${
                    pipe.stage === 'error' ? 'bg-rose-500' : 'bg-gradient-to-r from-emerald-600 to-emerald-400'
                  }`}
                  style={{ width: `${pipe.progress}%` }}
                />
              </div>
              {pipe.stage === 'model' && pipe.modelPct > 0 && pipe.modelPct < 100 && (
                <p className="text-[10px] text-sky-300 mt-1">Model download: {pipe.modelPct}%</p>
              )}
            </div>

            <div className="grid grid-cols-1 gap-1.5">
              {PIPELINE_STEPS.map((s, i) => {
                const done = stepIdx > i || pipe.stage === 'done';
                const cur = s.key === pipe.stage;
                return (
                  <div
                    key={s.key}
                    className={`flex items-center gap-3 text-xs px-3 py-2 rounded-xl border ${
                      done
                        ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300'
                        : cur
                          ? 'border-sky-500/40 bg-sky-500/10 text-sky-200'
                          : 'border-[#1f293d] bg-[#0b0f17]/40 text-slate-500'
                    }`}
                  >
                    <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border border-current">
                      {done ? '✓' : i + 1}
                    </span>
                    {bi(s.ckb, s.en)}
                  </div>
                );
              })}
            </div>

            <div
              ref={logRef}
              className="font-mono text-[11px] leading-relaxed bg-black/40 border border-[#1f293d] rounded-xl p-3 max-h-48 overflow-y-auto subtitle-scroll"
              dir="ltr"
            >
              {pipe.logs.map((l, i) => (
                <div key={i} className={logColor(l.kind)}>
                  <span className="text-slate-600">[{l.t}] </span>
                  {l.text}
                </div>
              ))}
              {pipe.active && <div className="text-emerald-500 animate-pulse">▊ working…</div>}
            </div>

            {pipe.error && (
              <div className="text-sm text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded-xl p-3">
                {pipe.error}
              </div>
            )}

            <div className="flex gap-2">
              {pipe.active && (
                <button
                  onClick={() => pipe.cancel()}
                  className="flex-1 py-3 rounded-xl border border-rose-500/40 text-rose-300 text-sm font-semibold hover:bg-rose-500/10"
                >
                  هەڵوەشاندنەوە (Cancel)
                </button>
              )}
              {(pipe.stage === 'done' || pipe.stage === 'error') && (
                <button
                  onClick={close}
                  className="flex-1 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-bold"
                >
                  داخستن (Close)
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
