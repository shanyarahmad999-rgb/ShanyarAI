import { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  Download,
  LoaderCircle,
  Pause,
  Play,
  Plus,
  Redo2,
  Scissors,
  Trash2,
  Undo2,
} from 'lucide-react';
import { formatSrtTime, parseSrtTime, downloadSrt } from '../lib/srt';
import { getVideoUrl } from '../lib/videoStore';

export type SubtitleRow = {
  id: number;
  project_id: number;
  segment_index: number;
  start_time: string;
  end_time: string;
  start_seconds: number;
  end_seconds: number;
  speaker: string;
  original_text: string;
  sorani_text: string;
  confidence: number | null;
};

type Project = {
  id: number;
  title: string;
  duration_seconds?: number;
  status?: string;
  original_lang?: string;
};

type Props = {
  project: Project;
  subtitles: SubtitleRow[];
  setSubtitles: (rows: SubtitleRow[]) => void;
  onBack: () => void;
  onChanged: () => void;
};

export default function Editor({
  project,
  subtitles,
  setSubtitles,
  onBack,
  onChanged,
}: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [missingVideo, setMissingVideo] = useState(false);
  const [filter, setFilter] = useState('');
  const [saving, setSaving] = useState(false);
  const [fontSize, setFontSize] = useState(18);
  const [undoStack, setUndoStack] = useState<string[]>([]);
  const [redoStack, setRedoStack] = useState<string[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    let url: string | null = null;
    let alive = true;
    getVideoUrl(project.id).then((u) => {
      if (!alive) return;
      if (u) {
        url = u;
        setVideoUrl(u);
        setMissingVideo(false);
      } else {
        setMissingVideo(true);
      }
    });
    return () => {
      alive = false;
      if (url) URL.revokeObjectURL(url);
    };
  }, [project.id]);

  const pushUndo = () => {
    setUndoStack((s) => [...s.slice(-49), JSON.stringify(subtitles)]);
    setRedoStack([]);
  };

  const undo = () => {
    if (!undoStack.length) return;
    setRedoStack((r) => [...r, JSON.stringify(subtitles)]);
    const prev = undoStack[undoStack.length - 1];
    setUndoStack((s) => s.slice(0, -1));
    setSubtitles(JSON.parse(prev));
    onChanged();
  };

  const redo = () => {
    if (!redoStack.length) return;
    setUndoStack((s) => [...s, JSON.stringify(subtitles)]);
    const next = redoStack[redoStack.length - 1];
    setRedoStack((s) => s.slice(0, -1));
    setSubtitles(JSON.parse(next));
    onChanged();
  };

  const saveRow = async (id: number, patch: Partial<SubtitleRow>) => {
    setBusyId(id);
    try {
      const r = await fetch('/api/subtitles', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...patch }),
      });
      if (!r.ok) throw new Error();
      const updated = await r.json();
      setSubtitles(subtitles.map((s) => (s.id === id ? updated : s)));
      onChanged();
    } catch {
      alert('Could not save to database. Check your connection.');
    } finally {
      setBusyId(null);
    }
  };

  const localPatch = (id: number, patch: Partial<SubtitleRow>) => {
    setSubtitles(subtitles.map((s) => (s.id === id ? { ...s, ...patch } : s)));
  };

  const onTimeChange = (id: number, field: 'start_time' | 'end_time', value: string) => {
    pushUndo();
    const sec = parseSrtTime(value);
    const patch =
      field === 'start_time'
        ? { start_time: value, ...(sec !== null ? { start_seconds: sec } : {}) }
        : { end_time: value, ...(sec !== null ? { end_seconds: sec } : {}) };
    localPatch(id, patch);
    if (sec !== null) saveRow(id, patch);
  };

  const deleteRow = async (id: number) => {
    if (!confirm('Delete this subtitle row?')) return;
    pushUndo();
    setSubtitles(subtitles.filter((s) => s.id !== id));
    try {
      await fetch('/api/subtitles', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      onChanged();
    } catch {
      /* ignore */
    }
  };

  const splitRow = async (id: number) => {
    const idx = subtitles.findIndex((s) => s.id === id);
    if (idx < 0) return;
    pushUndo();
    const z = subtitles[idx];
    const mid = (z.start_seconds + z.end_seconds) / 2;
    const words = z.sorani_text.split(/\s+/).filter(Boolean);
    const half = Math.max(1, Math.ceil(words.length / 2));
    try {
      await fetch('/api/subtitles', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const r = await fetch('/api/subtitles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          project_id: project.id,
          segments: [
            {
              segment_index: idx * 2,
              start_time: z.start_time,
              end_time: formatSrtTime(mid),
              start_seconds: z.start_seconds,
              end_seconds: mid,
              speaker: z.speaker,
              original_text: z.original_text,
              sorani_text: words.slice(0, half).join(' ') || z.sorani_text,
              confidence: z.confidence,
            },
            {
              segment_index: idx * 2 + 1,
              start_time: formatSrtTime(mid + 0.1),
              end_time: z.end_time,
              start_seconds: mid + 0.1,
              end_seconds: z.end_seconds,
              speaker: z.speaker,
              original_text: z.original_text,
              sorani_text: words.slice(half).join(' ') || '…',
              confidence: z.confidence,
            },
          ],
        }),
      });
      // reload all for this project to keep indices clean
      const all = await fetch(`/api/subtitles?project_id=${project.id}`).then((x) => x.json());
      setSubtitles(all);
      onChanged();
      void r;
    } catch {
      alert('Split failed — check connection.');
    }
  };

  const addRow = async () => {
    pushUndo();
    const last = subtitles[subtitles.length - 1];
    const start = last ? last.end_seconds + 0.5 : 0;
    const end = start + 3;
    try {
      const r = await fetch('/api/subtitles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          project_id: project.id,
          segments: [
            {
              segment_index: subtitles.length,
              start_time: formatSrtTime(start),
              end_time: formatSrtTime(end),
              start_seconds: start,
              end_seconds: end,
              speaker: 'Speaker 1',
              original_text: 'New spoken sentence...',
              sorani_text: 'ڕستەی نوێی ژێرنووس',
            },
          ],
        }),
      });
      // append returned or refetch
      if (r.ok) {
        const all = await fetch(`/api/subtitles?project_id=${project.id}`).then((x) => x.json());
        setSubtitles(all);
        onChanged();
      }
    } catch {
      alert('Could not add row.');
    }
  };

  const download = () => {
    const name = (project.title || 'kurdsub').replace(/[^\w\u0600-\u06FF._-]/g, '_');
    downloadSrt(subtitles, `${name}.srt`);
  };

  const filtered = filter
    ? subtitles.filter(
        (s) =>
          s.sorani_text.toLowerCase().includes(filter.toLowerCase()) ||
          (s.original_text || '').toLowerCase().includes(filter.toLowerCase())
      )
    : subtitles;

  const activeCue =
    subtitles.find(
      (s) => currentTime >= s.start_seconds && currentTime <= s.end_seconds
    ) || null;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl border border-[#1f293d] text-slate-300 hover:bg-[#0b0f17]"
          >
            <ArrowRight className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-lg font-bold text-white">{project.title || 'پڕۆژە'}</h2>
            <p className="text-xs text-slate-400">
              {subtitles.length} ژێرنووس · {project.original_lang || '—'} → ckb
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={undo}
            disabled={!undoStack.length}
            className="p-2 rounded-xl border border-[#1f293d] text-slate-300 disabled:opacity-30"
            title="Undo"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            onClick={redo}
            disabled={!redoStack.length}
            className="p-2 rounded-xl border border-[#1f293d] text-slate-300 disabled:opacity-30"
            title="Redo"
          >
            <Redo2 className="w-4 h-4" />
          </button>
          <button
            onClick={addRow}
            className="px-3 py-2 rounded-xl border border-[#1f293d] text-slate-200 text-xs flex items-center gap-1.5 hover:bg-[#0b0f17]"
          >
            <Plus className="w-3.5 h-3.5" /> زیادکردن
          </button>
          <button
            onClick={download}
            className="px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" /> داگرتنی SRT
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <div className="lg:col-span-2 space-y-3">
          <div className="relative rounded-2xl overflow-hidden border border-[#1f293d] bg-black aspect-video">
            {videoUrl ? (
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-contain"
                onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
                onPlay={() => setPlaying(true)}
                onPause={() => setPlaying(false)}
                controls
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-slate-500 text-sm p-6 text-center">
                {missingVideo
                  ? 'ڤیدیۆ لەم ئامێرەدا پاشەکەوت نەکراوە (IndexedDB). ژێرنووسەکان هێشتا دەستکاری دەکرێن.'
                  : 'Loading video…'}
              </div>
            )}
            {activeCue && (
              <div
                className="absolute bottom-10 inset-x-4 text-center pointer-events-none"
                style={{ fontSize }}
              >
                <span className="inline-block px-3 py-1.5 rounded-lg bg-black/75 text-white font-kurdish leading-relaxed video-overlay-subtitle">
                  {activeCue.sorani_text}
                </span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const v = videoRef.current;
                if (!v) return;
                if (v.paused) v.play();
                else v.pause();
              }}
              className="p-2 rounded-xl bg-[#0b0f17] border border-[#1f293d] text-white"
            >
              {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            <label className="text-xs text-slate-400 flex items-center gap-2 flex-1">
              قەبارەی فۆنت
              <input
                type="range"
                min={14}
                max={32}
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="flex-1 accent-emerald-500"
              />
            </label>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-3">
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            placeholder="گەڕان لە ژێرنووس…"
            className="w-full bg-[#0b0f17] border border-[#1f293d] rounded-xl px-3 py-2 text-sm text-slate-200 outline-none focus:border-emerald-500"
          />
          <div className="space-y-3 max-h-[640px] overflow-y-auto pr-1 subtitle-scroll">
            {filtered.map((row) => {
              const on = activeCue?.id === row.id;
              return (
                <div
                  key={row.id}
                  onClick={() => {
                    setActiveId(row.id);
                    if (videoRef.current) videoRef.current.currentTime = row.start_seconds;
                  }}
                  className={`rounded-2xl border p-3 space-y-2 transition cursor-pointer ${
                    on
                      ? 'border-emerald-500/50 bg-emerald-500/5'
                      : activeId === row.id
                        ? 'border-sky-500/40 bg-sky-500/5'
                        : 'border-[#1f293d] bg-[#131b2a]'
                  }`}
                >
                  <div className="flex flex-wrap items-center gap-2 text-[11px]">
                    <input
                      value={row.start_time}
                      onChange={(e) => onTimeChange(row.id, 'start_time', e.target.value)}
                      className="w-[7.5rem] bg-[#0b0f17] border border-[#1f293d] rounded-lg px-2 py-1 font-mono text-emerald-300"
                      dir="ltr"
                    />
                    <span className="text-slate-500">→</span>
                    <input
                      value={row.end_time}
                      onChange={(e) => onTimeChange(row.id, 'end_time', e.target.value)}
                      className="w-[7.5rem] bg-[#0b0f17] border border-[#1f293d] rounded-lg px-2 py-1 font-mono text-emerald-300"
                      dir="ltr"
                    />
                    <select
                      value={row.speaker || 'Speaker 1'}
                      onChange={(e) => {
                        pushUndo();
                        localPatch(row.id, { speaker: e.target.value });
                        saveRow(row.id, { speaker: e.target.value });
                      }}
                      className="bg-[#0b0f17] border border-[#1f293d] rounded-lg px-2 py-1 text-slate-300"
                    >
                      <option>Speaker 1</option>
                      <option>Speaker 2</option>
                      <option>Speaker 3</option>
                    </select>
                    <div className="flex-1" />
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        splitRow(row.id);
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#0b0f17]"
                      title="Split"
                    >
                      <Scissors className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteRow(row.id);
                      }}
                      className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    {busyId === row.id && (
                      <LoaderCircle className="w-3.5 h-3.5 animate-spin text-sky-400" />
                    )}
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 mb-1">دەقی وەرگێڕدراوی کوردی سۆرانی:</div>
                    <textarea
                      value={row.sorani_text}
                      onChange={(e) => localPatch(row.id, { sorani_text: e.target.value })}
                      onBlur={() => {
                        setSaving(true);
                        saveRow(row.id, { sorani_text: row.sorani_text }).finally(() =>
                          setSaving(false)
                        );
                      }}
                      rows={2}
                      className="w-full bg-[#0b0f17] border border-[#1f293d] rounded-xl px-3 py-2 text-sm text-white font-kurdish leading-relaxed outline-none focus:border-emerald-500"
                      dir="rtl"
                    />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 mb-1">Original transcript:</div>
                    <div className="text-xs text-slate-400 leading-relaxed" dir="auto">
                      {row.original_text}
                    </div>
                  </div>
                </div>
              );
            })}
            {!filtered.length && (
              <div className="text-center text-slate-500 text-sm py-10">هیچ ژێرنووسێک نیە</div>
            )}
          </div>
          {saving && <div className="text-[10px] text-slate-500">Saving…</div>}
        </div>
      </div>
    </div>
  );
}
