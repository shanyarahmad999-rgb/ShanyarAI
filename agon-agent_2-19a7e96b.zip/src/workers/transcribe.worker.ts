/**
 * Web Worker: Whisper ASR via @xenova/transformers (ONNX).
 * Model: Xenova/whisper-base — better accuracy than tiny; still runnable in-browser.
 * Returns chunk timestamps; when available, word-level timestamps are also forwarded.
 */
import { pipeline, env } from '@xenova/transformers';

// Always fetch from CDN / HF; cache in browser Cache API.
env.allowLocalModels = false;
(env as { useBrowserCache?: boolean }).useBrowserCache = true;

/** Prefer base; fall back to small only if explicitly set via message (not default — RAM). */
const MODEL_ID = 'Xenova/whisper-base';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let transcriber: any = null;

self.onmessage = async (ev: MessageEvent) => {
  const msg = ev.data;
  try {
    if (msg.type === 'load') {
      const modelId = typeof msg.model === 'string' && msg.model ? msg.model : MODEL_ID;
      transcriber = await pipeline('automatic-speech-recognition', modelId, {
        // quantized onnx is default for Xenova models
        progress_callback: (p: unknown) => {
          self.postMessage({ type: 'load-progress', payload: p });
        },
      });
      self.postMessage({ type: 'loaded', model: modelId });
      return;
    }

    if (msg.type === 'transcribe') {
      if (!transcriber) throw new Error('Model not loaded');

      const opts: Record<string, unknown> = {
        // Let the pipeline chunk long audio; we also window on the main thread.
        chunk_length_s: 30,
        stride_length_s: 5,
        return_timestamps: true,
        task: 'transcribe',
      };
      if (msg.language) opts.language = msg.language;

      // Prefer word timestamps when the model/tokenizer path supports it.
      // transformers.js Whisper uses return_timestamps: 'word' in recent versions.
      let result;
      try {
        result = await transcriber(msg.audio, {
          ...opts,
          return_timestamps: 'word',
        });
      } catch {
        result = await transcriber(msg.audio, opts);
      }

      self.postMessage({
        type: 'result',
        chunkIndex: msg.chunkIndex,
        payload: result,
      });
      return;
    }
  } catch (err) {
    self.postMessage({
      type: 'error',
      chunkIndex: msg.type === 'transcribe' ? msg.chunkIndex : -1,
      message: err instanceof Error ? err.message : String(err),
    });
  }
};
