import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Captions,
  CircleCheck,
  Clock3,
  Download,
  Film,
  LayoutDashboard,
  LoaderCircle,
  PencilLine,
  Plus,
  Server,
  Sparkles,
  Trash2,
  TrendingUp,
  TriangleAlert,
} from 'lucide-react';
import UploadModal from '../components/UploadModal';
import Editor, { type SubtitleRow } from '../components/Editor';
import { downloadSrt } from '../lib/srt';
import { deleteVideo } from '../lib/videoStore';

type Project = {
  id: number;
  title: string;
  original_lang?: string;
  target_lang?: string;
  duration_seconds?: number;
  status?: string;
  progress?: number;
  stage?: string;
  error?: string | null;
  updated_at?: string;
  created_at?: string;
};

type Tab = 'dashboard' | 'editor' | 'backend';

export default function Dashboard() {
  const [tab, setTab] = useState<Tab>('dashboard');
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [selected, setSelected] = useState<Project | null>(null);
  const [subs, setSubs] = useState<SubtitleRow[]>([]);
  const [subsLoading, setSubsLoading] = useState(false);
  const [backendTab, setBackendTab] = useState<'pipeline' | 'schema' | 'security'>('pipeline');

  const loadProjects = useCallback(async () => {
    try {
      const r = await fetch('/api/projects');
      const data = await r.json();
      setProjects(Array.isArray(data) ? data : []);
    } catch {
      setProjects([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadProjects();
  }, [loadProjects]);

  const stats = useMemo(() => {
    const completed = projects.filter((p) => p.status === 'completed');
    const totalMin = projects.reduce((s, p) => s + (p.duration_seconds || 0), 0) / 60;
    return {
      total: projects.length,
      completed: completed.length,
      minutes: Math.round(totalMin * 10) / 10,
    };
  }, [projects]);

  const openEditor = async (p: Project) => {
    setSelected(p);
    setSubsLoading(true);
    setTab('editor');
    try {
      const r = await fetch(`/api/subtitles?project_id=${p.id}`);
      const data = r.ok ? await r.json() : [];
      setSubs(Array.isArray(data) ? data : []);
    } catch {
      setSubs([]);
    } finally {
      setSubsLoading(false);
    }
  };

  const refreshSubs = async () => {
    if (!selected) return;
    const r = await fetch(`/api/subtitles?project_id=${selected.id}`);
    if (r.ok) setSubs(await r.json());
  };

  const removeProject = async (p: Project) => {
    if (!confirm(`Delete project “${p.title}”?`)) return;
    await fetch('/api/projects', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: p.id }),
    });
    await deleteVideo(p.id);
    if (selected?.id === p.id) {
      setSelected(null);
      setSubs([]);
      setTab('dashboard');
    }
    loadProjects();
  };

  const downloadProject = async (p: Project) => {
    try {
      const r = await fetch(`/api/subtitles?project_id=${p.id}`);
      const rows = await r.json();
      const name = (p.title || 'kurdsub').replace(/[^\w\u0600-\u06FF._-]/g, '_');
      downloadSrt(rows, `${name}.srt`);
    } catch (e) {
      alert(e instanceof Error ? e.message : 'نەتوانرا SRT دابگیرێت');
    }
  };

  const navBtn = (id: Tab, label: string, icon: ReactNode) => (
    <button
      onClick={() => setTab(id)}
      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition ${
        tab === id ? 'bg-emerald-500/20 text-emerald-300' : 'text-slate-400 hover:text-white'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  const statusBadge = (status?: string) => {
    const s = status || 'unknown';
    const map: Record<string, string> = {
      completed: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
      processing: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
      failed: 'bg-rose-500/15 text-rose-300 border-rose-500/30',
      queued: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
    };
    return (
      <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${map[s] || 'bg-slate-500/15 text-slate-300 border-slate-500/30'}`}>
        {s}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-200 flex flex-col font-sans" dir="rtl">
      <header className="sticky top-0 z-40 border-b border-[#1f293d] bg-[#0b0f17]/90 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 via-emerald-500 to-amber-400 flex items-center justify-center shadow-lg">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-white" dir="ltr">
                  KurdSub <span className="text-emerald-400">AI</span>
                </span>
                <span
                  className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-medium border border-emerald-500/30"
                  dir="ltr"
                >
                  v2.6 QUALITY
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                سیستەمی زیرەکی دەستکرد بۆ ژێرنووسی کوردی
              </p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-1 bg-[#0b0f17]/60 p-1 rounded-xl border border-[#1f293d] text-sm">
            {navBtn('dashboard', 'داشبۆرد', <LayoutDashboard className="w-4 h-4" />)}
            {navBtn('editor', 'دەستکاریکەری ژێرنووس', <PencilLine className="w-4 h-4" />)}
            {navBtn('backend', 'کۆد و بیناسازی', <Server className="w-4 h-4" />)}
          </nav>
          <button
            onClick={() => setUploadOpen(true)}
            className="bg-emerald-500 hover:bg-emerald-600 text-white px-3.5 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">پڕۆژەی نوێ</span>
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {tab === 'dashboard' && (
          <div className="space-y-8">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#131b2a] via-slate-900 to-emerald-950 border border-[#1f293d] p-6 sm:p-10">
              <div className="relative z-10 max-w-3xl space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold">
                  <Sparkles className="w-3.5 h-3.5" /> Whisper Base STT لە براوزەرەکەتدا + وەرگێڕانی
                  سۆرانی — بەبێ سێرڤەری ساختە
                </div>
                <h1 className="text-3xl sm:text-5xl font-black text-white leading-tight">
                  ڤیدیۆکانت بە زیرەکی بۆ{' '}
                  <span className="bg-gradient-to-l from-emerald-400 via-amber-300 to-emerald-500 bg-clip-text text-transparent">
                    کوردیی سۆرانی
                  </span>{' '}
                  ژێرنووس بکە
                </h1>
                <p className="text-slate-300 text-base sm:text-lg leading-relaxed">
                  AUDIO → Whisper Base (word timestamps) → natural segmentation → Google/MyMemory
                  Sorani MT → UTF-8 SRT. Real pipeline, no simulated results.
                </p>
                <button
                  onClick={() => setUploadOpen(true)}
                  className="mt-2 inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-3 rounded-2xl font-bold shadow-lg shadow-emerald-900/30"
                >
                  <Plus className="w-5 h-5" /> پڕۆژەی نوێ
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                { label: 'کۆی پڕۆژەکان', value: stats.total, icon: Film },
                { label: 'تەواوبوو', value: stats.completed, icon: CircleCheck },
                { label: 'خولەکی پرۆسەکراو', value: stats.minutes, icon: Clock3 },
                { label: 'ژێرنووسە پاشەکەوتکراوەکان', value: 'completed in database', icon: Captions },
              ].map((c) => (
                <div
                  key={c.label}
                  className="rounded-2xl border border-[#1f293d] bg-[#131b2a] p-4 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-slate-400">{c.label}</span>
                    <c.icon className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl font-black text-white" dir="ltr">
                    {c.value}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl border border-[#1f293d] bg-[#131b2a] overflow-hidden">
              <div className="px-4 py-3 border-b border-[#1f293d] flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-white flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-400" /> دۆخی پایپڵاین
                  </h3>
                  <p className="text-[11px] text-slate-500" dir="ltr">
                    browser worker + /api/*
                  </p>
                </div>
                <p className="text-xs text-slate-400 hidden sm:block">
                  بەڕێوەبردن و داگرتنی فایلەکانی ژێرنووسی .SRT — هەموو داتاکە لە داتابەیسەوە دێت
                </p>
              </div>

              {loading ? (
                <div className="p-10 flex justify-center text-slate-400 gap-2">
                  <LoaderCircle className="w-5 h-5 animate-spin" /> Loading…
                </div>
              ) : !projects.length ? (
                <div className="p-12 text-center space-y-3">
                  <Film className="w-10 h-10 text-slate-600 mx-auto" />
                  <p className="text-slate-400">هیچ پڕۆژەیەک نیە — یەکەم ڤیدیۆکەت باربکە</p>
                  <button
                    onClick={() => setUploadOpen(true)}
                    className="inline-flex items-center gap-2 bg-emerald-500 text-white px-4 py-2 rounded-xl text-sm font-bold"
                  >
                    <Plus className="w-4 h-4" /> پڕۆژەی نوێ
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-[#1f293d]">
                  {projects.map((p) => (
                    <div
                      key={p.id}
                      className="p-4 flex flex-wrap items-center gap-3 hover:bg-white/[0.02]"
                    >
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                        <Film className="w-5 h-5 text-emerald-400" />
                      </div>
                      <div className="flex-1 min-w-[160px]">
                        <div className="font-semibold text-white">{p.title || 'Untitled'}</div>
                        <div className="text-[11px] text-slate-500 flex flex-wrap gap-2" dir="ltr">
                          <span>#{p.id}</span>
                          <span>{p.original_lang || '—'} → ckb</span>
                          <span>{p.duration_seconds ?? 0}s</span>
                          {statusBadge(p.status)}
                        </div>
                        {p.error && (
                          <div className="text-[11px] text-rose-400 flex items-center gap-1 mt-1">
                            <TriangleAlert className="w-3 h-3" /> {p.error}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => openEditor(p)}
                          className="p-2 rounded-xl border border-[#1f293d] text-slate-300 hover:text-white hover:bg-[#0b0f17]"
                          title="Edit"
                        >
                          <PencilLine className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => downloadProject(p)}
                          className="p-2 rounded-xl border border-[#1f293d] text-slate-300 hover:text-emerald-300 hover:bg-[#0b0f17]"
                          title="داگرتنی SRT"
                          disabled={p.status !== 'completed'}
                        >
                          <Download className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => removeProject(p)}
                          className="p-2 rounded-xl border border-[#1f293d] text-rose-400 hover:bg-rose-500/10"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'editor' && (
          <div>
            {subsLoading ? (
              <div className="p-16 text-center text-slate-400 flex justify-center gap-2">
                <LoaderCircle className="animate-spin w-5 h-5" /> Loading subtitles…
              </div>
            ) : selected ? (
              <Editor
                project={selected}
                subtitles={subs}
                setSubtitles={setSubs}
                onBack={() => setTab('dashboard')}
                onChanged={loadProjects}
              />
            ) : (
              <div className="p-16 text-center space-y-3">
                <p className="text-slate-400">پڕۆژەیەک هەڵبژێرە بۆ دەستکاریکردن</p>
                <button
                  onClick={() => setTab('dashboard')}
                  className="text-emerald-400 text-sm underline"
                >
                  گەڕانەوە بۆ داشبۆرد
                </button>
              </div>
            )}
            {selected && (
              <button onClick={refreshSubs} className="sr-only">
                refresh
              </button>
            )}
          </div>
        )}

        {tab === 'backend' && (
          <div className="space-y-4">
            <div className="flex gap-2 flex-wrap">
              {(
                [
                  ['pipeline', 'Pipeline'],
                  ['schema', 'Schema'],
                  ['security', 'Security'],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  onClick={() => setBackendTab(id)}
                  className={`px-3 py-1.5 rounded-lg text-sm border ${
                    backendTab === id
                      ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                      : 'border-[#1f293d] text-slate-400'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            <pre
              className="rounded-2xl border border-[#1f293d] bg-[#070a10] p-4 text-[11px] leading-relaxed overflow-auto max-h-[70vh] text-emerald-200/90 font-mono"
              dir="ltr"
            >
              {backendTab === 'pipeline' &&
                `// REAL pipeline v2.6 — improved quality
// VIDEO
//   → decodeTo16kMono() + peakNormalize + HPF/soft-gate  (src/lib/audio.ts)
//   → Whisper BASE via transformers.js worker            (src/workers/transcribe.worker.ts)
//       Xenova/whisper-base, return_timestamps word|chunk, 25s hop / 5s overlap
//   → Auto language detection on first window when source=auto
//   → mergeToSubtitles() pauses + punctuation + CPS      (src/lib/segment.ts)
//   → POST /api/translate  Google(ckb) → MyMemory → fallback
//   → POST /api/projects + /api/subtitles  (Supabase)
//   → SRT UTF-8 BOM download from saved rows`}
              {backendTab === 'schema' &&
                `-- projects / subtitles (Supabase Postgres)
create table projects (
  id bigint generated always as identity primary key,
  title text, original_lang text, target_lang text,
  video_url text, duration_seconds numeric,
  status text, progress int, stage text, error text,
  created_at timestamptz, updated_at timestamptz
);
create table subtitles (
  id bigint generated always as identity primary key,
  project_id bigint references projects(id),
  segment_index int, start_time text, end_time text,
  start_seconds numeric, end_seconds numeric,
  speaker text, original_text text, sorani_text text,
  confidence numeric, created_at timestamptz
);`}
              {backendTab === 'security' &&
                `// Video bytes stay in IndexedDB on-device (never uploaded to serverless).
// Only transcript strings hit /api/translate + subtitle rows in Postgres.
// No API keys required for Google clients5 / MyMemory public endpoints.
// Whisper model cached in browser Cache Storage after first download.`}
            </pre>
          </div>
        )}
      </main>

      <footer className="border-t border-[#1f293d] py-4 text-center text-[11px] text-slate-500">
        <span dir="ltr">KurdSub AI</span> — ژێرنووسیکردنی ڤیدیۆ بە کوردی سۆرانی · Whisper STT +
        Sorani MT + UTF-8 SRT
      </footer>

      <UploadModal
        open={uploadOpen}
        onClose={() => setUploadOpen(false)}
        onComplete={(p) => {
          setUploadOpen(false);
          loadProjects();
          openEditor(p as Project);
        }}
      />
    </div>
  );
}
