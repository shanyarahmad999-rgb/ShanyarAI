import { useCallback, useEffect, useRef, useState } from 'react';
import {
  SAMPLE_RATE,
  decodeTo16kMono,
  peakNormalize,
  enhanceSpeech,
  meanAbsEnergy,
} from '../lib/audio';
import {
  detectSpeechTurns,
  mergeToSubtitles,
  refineWithPauses,
  type TimedPiece,
} from '../lib/segment';
import { formatSrtTime } from '../lib/srt';
import { saveVideo } from '../lib/videoStore';

export type LogKind = 'info' | 'ok' | 'warn' | 'err' | 'model';
export type LogLine = { t: string; kind: LogKind; text: string };

export const PIPELINE_STEPS = [
  { key: 'upload', pct: 8, ckb: '1. بارکردنی ڤیدیۆ و پاشەکەوت', en: '1. Upload & storage' },
  {
    key: 'extract',
    pct: 18,
    ckb: '2. دەرهێنانی دەنگ (16kHz mono PCM)',
    en: '2. Audio extraction (16kHz mono)',
  },
  { key: 'model', pct: 30, ckb: '3. ئامادەکردنی مۆدێلی Whisper', en: '3. Loading Whisper model' },
  {
    key: 'transcribe',
    pct: 68,
    ckb: '4. ناسینەوەی دەنگ بۆ دەق (Whisper)',
    en: '4. Speech-to-text (Whisper)',
  },
  { key: 'timing', pct: 72, ckb: '5. دیاریکردنی ئاخێوەر و کات', en: '5. Speaker turns & timing' },
  {
    key: 'translate',
    pct: 92,
    ckb: '6. وەرگێڕان بۆ کوردی سۆرانی سروشتی',
    en: '6. Translation to natural Sorani',
  },
  { key: 'save', pct: 97, ckb: '7. پاشەکەوتکردن لە داتابەیس', en: '7. Saving to database' },
  { key: 'done', pct: 100, ckb: '8. تەواوبوو — ئامادەی داگرتنە', en: '8. Done' },
] as const;

const WINDOW_SEC = 30;
const TRANSLATE_BATCH = 8;
/** Whisper-base ~150MB quantized; better WER + timestamps than tiny. */
const WHISPER_MODEL = 'Xenova/whisper-base';

function nowTime() {
  return new Date().toLocaleTimeString();
}

type WorkerResult = {
  text?: string;
  chunks?: {
    text?: string;
    timestamp?: [number | null, number | null];
  }[];
};

function piecesFromWhisper(
  result: WorkerResult,
  offsetSec: number
): TimedPiece[] {
  const pieces: TimedPiece[] = [];
  const chunks = Array.isArray(result.chunks) ? result.chunks : [];

  for (const ch of chunks) {
    const text = (ch.text || '').trim();
    if (!text) continue;
    const [ts0, ts1] = ch.timestamp || [0, 0];
    const start = offsetSec + (typeof ts0 === 'number' ? ts0 : 0);
    let end = offsetSec + (typeof ts1 === 'number' && ts1 != null ? ts1 : typeof ts0 === 'number' ? ts0 : 0);
    if (end <= start) end = start + 0.05;

    // Word-level: if chunk text has multiple words and only chunk ts, keep as one piece
    // (worker may return word timestamps as separate chunks with short spans)
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length > 1 && end - start > 0.2) {
      // Approximate word timings inside chunk (better than none); real word ts used when present as single-word chunks
      const dur = end - start;
      const total = words.reduce((s, w) => s + w.length, 0) || 1;
      let t = start;
      const wordTs = words.map((w, i) => {
        const share = (w.length / total) * dur;
        const we = i === words.length - 1 ? end : t + Math.max(share, 0.04);
        const item = { word: w, start: t, end: we };
        t = we;
        return item;
      });
      pieces.push({ start, end, text, words: wordTs });
    } else {
      pieces.push({ start, end, text });
    }
  }

  if (!chunks.length && (result.text || '').trim()) {
    pieces.push({
      start: offsetSec,
      end: offsetSec + 1,
      text: (result.text || '').trim(),
    });
  }
  return pieces;
}

/** Detect language from Whisper when user chose Auto (no language forced). */
function detectLangFromResult(result: WorkerResult & { language?: string }): string | null {
  if (result && typeof (result as { language?: string }).language === 'string') {
    return (result as { language: string }).language;
  }
  return null;
}

export function usePipeline() {
  const [active, setActive] = useState(false);
  const [stage, setStage] = useState('idle');
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<LogLine[]>([]);
  const [modelPct, setModelPct] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const workerRef = useRef<Worker | null>(null);
  const pending = useRef(new Map<number, { resolve: (v: unknown) => void; reject: (e: Error) => void }>());
  const nextId = useRef(0);
  const cancelled = useRef(false);
  const modelReady = useRef<Promise<void> | null>(null);

  const pushLog = useCallback((text: string, kind: LogKind = 'info') => {
    setLogs((prev) => [...prev.slice(-300), { t: nowTime(), kind, text }]);
  }, []);

  useEffect(
    () => () => {
      try {
        workerRef.current?.terminate();
      } catch {
        /* ignore */
      }
    },
    []
  );

  const getWorker = useCallback(() => {
    if (workerRef.current) return workerRef.current;
    const w = new Worker(new URL('../workers/transcribe.worker.ts', import.meta.url), {
      type: 'module',
    });
    w.onmessage = (ev: MessageEvent) => {
      const msg = ev.data;
      if (msg.type === 'load-progress') {
        const p = msg.payload;
        if (p && typeof p.progress === 'number') setModelPct(Math.round(p.progress));
      } else if (msg.type === 'loaded') {
        setModelPct(100);
      } else if (msg.type === 'result') {
        const pr = pending.current.get(msg.chunkIndex ?? -1);
        if (pr) {
          pending.current.delete(msg.chunkIndex ?? -1);
          pr.resolve(msg.payload);
        }
      } else if (msg.type === 'error') {
        const pr = pending.current.get(msg.chunkIndex ?? -1);
        const err = new Error(msg.message || 'Worker error');
        if (pr && (msg.chunkIndex ?? -1) >= 0) {
          pending.current.delete(msg.chunkIndex ?? -1);
          pr.reject(err);
        } else {
          console.error('[worker]', err);
        }
      }
    };
    workerRef.current = w;
    return w;
  }, []);

  const ensureModel = useCallback(
    async (log: (m: string, k?: LogKind) => void) => {
      if (modelReady.current) {
        await modelReady.current;
        return;
      }
      const w = getWorker();
      log(
        `[whisper] loading speech model (${WHISPER_MODEL}, quantized ONNX — first run downloads & caches)…`,
        'model'
      );
      modelReady.current = new Promise<void>((resolve, reject) => {
        const timer = setTimeout(
          () => reject(new Error('Model download timed out (check connection, then retry)')),
          600_000
        );
        const onMsg = (ev: MessageEvent) => {
          const m = ev.data;
          if (m.type === 'loaded') {
            clearTimeout(timer);
            w.removeEventListener('message', onMsg);
            resolve();
          } else if (m.type === 'error' && ev.data.chunkIndex === -1) {
            clearTimeout(timer);
            w.removeEventListener('message', onMsg);
            modelReady.current = null;
            reject(new Error(m.message || 'Model load failed'));
          }
        };
        w.addEventListener('message', onMsg);
        w.postMessage({ type: 'load', model: WHISPER_MODEL });
      });
      try {
        await modelReady.current;
        log(`[whisper] model ready (${WHISPER_MODEL})`, 'ok');
      } catch (e) {
        modelReady.current = null;
        throw e;
      }
    },
    [getWorker]
  );

  const transcribeChunk = useCallback(
    (audio: Float32Array, language?: string) => {
      const w = getWorker();
      const id = nextId.current++;
      return new Promise<WorkerResult>((resolve, reject) => {
        pending.current.set(id, {
          resolve: (v) => resolve(v as WorkerResult),
          reject,
        });
        const copy = new Float32Array(audio);
        w.postMessage({ type: 'transcribe', chunkIndex: id, audio: copy, language }, [
          copy.buffer,
        ]);
      });
    },
    [getWorker]
  );

  const checkCancel = () => {
    if (cancelled.current) throw new Error('CANCELLED');
  };

  const patchProject = useCallback(async (id: number, patch: Record<string, unknown>) => {
    try {
      await fetch('/api/projects', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...patch }),
      });
    } catch {
      /* ignore progress failures */
    }
  }, []);

  const run = useCallback(
    async (opts: {
      file: File;
      title: string;
      sourceLang: string;
      cleanupAudio: boolean;
      diarization: boolean;
      onDone: (project: Record<string, unknown>) => void;
    }) => {
      const { file, title, sourceLang, cleanupAudio, diarization, onDone } = opts;
      cancelled.current = false;
      setError(null);
      setLogs([]);
      setModelPct(0);
      setActive(true);
      let projectId: number | null = null;

      const log = (text: string, kind: LogKind = 'info') => pushLog(text, kind);
      const setS = (s: string, p: number) => {
        setStage(s);
        setProgress(p);
      };

      try {
        setS('upload', 4);
        log(`[upload] ${file.name} (${(file.size / 1048576).toFixed(2)} MB)`);
        if (file.size > 500 * 1048576) throw new Error('File exceeds the 500 MB limit.');
        if (
          !/^(video|audio)\//.test(file.type) &&
          !/\.(mp4|mov|mkv|webm|mp3|wav|m4a|ogg|flac)$/i.test(file.name)
        ) {
          throw new Error(
            `Unsupported file type (${file.type || 'unknown'}). Use MP4/MOV/MKV/WEBM/MP3/WAV.`
          );
        }

        checkCancel();
        setS('extract', 10);
        log('[extract] decoding audio track (Web Audio API)…');
        let decoded = await decodeTo16kMono(file, (m) => log(m));

        if (cleanupAudio) {
          let samples = peakNormalize(decoded.samples, (m) => log(m));
          samples = enhanceSpeech(samples, (m) => log(m));
          // Re-normalize after enhance
          samples = peakNormalize(samples, (m) => log(m));
          decoded = { ...decoded, samples };
        } else {
          log('[audio] cleanup toggle off — using raw mono mix');
        }

        const energy = meanAbsEnergy(decoded.samples);
        log(
          `[audio] mean energy ${energy.toFixed(4)}${
            energy < 0.008 ? ' — WARNING: very quiet, transcription may be empty' : ''
          }`,
          energy < 0.008 ? 'warn' : 'info'
        );

        setS('extract', 18);
        checkCancel();
        log('[db] creating project row…');
        const created = await (async () => {
          const r = await fetch('/api/projects', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              title: title || file.name.replace(/\.[^.]+$/, ''),
              original_lang: sourceLang,
              target_lang: 'ckb',
              video_url: 'local',
              duration_seconds: Math.round(decoded.durationSec * 100) / 100,
              status: 'processing',
            }),
          });
          if (!r.ok) throw new Error(`Database unreachable (${r.status}). Check Supabase config.`);
          return r.json();
        })();
        projectId = created.id;
        await saveVideo(created.id, file);
        log(`[db] project #${created.id} created, video stored locally`, 'ok');

        checkCancel();
        setS('model', 22);
        await ensureModel((m, k) => log(m, k));
        checkCancel();
        setS('transcribe', 32);

        const totalSamples = decoded.samples.length;
        const windowSamples = WINDOW_SEC * SAMPLE_RATE;
        // 5s overlap between windows to avoid cutting words; de-dupe later by time
        const hopSamples = Math.floor(25 * SAMPLE_RATE);
        const windows = Math.max(1, Math.ceil(totalSamples / hopSamples));
        log(
          `[whisper] transcribing ${decoded.durationSec.toFixed(1)}s with ${WHISPER_MODEL} (${windows} window(s), 5s overlap)…`
        );

        // Auto-detect: do NOT force language on first window; use Whisper's detection
        let forcedLang: string | undefined =
          sourceLang !== 'auto' && sourceLang !== 'ku' ? sourceLang : undefined;
        let detectedLang: string | null = sourceLang === 'ku' ? 'ku' : null;

        if (sourceLang === 'ku') {
          log('[whisper] source is Sorani — transcribing speech, then normalizing text (no MT)', 'warn');
        }
        if (sourceLang === 'auto') {
          log('[whisper] Auto Detect — first window will detect spoken language…');
        }

        const allPieces: TimedPiece[] = [];
        for (let w = 0; w < windows; w++) {
          checkCancel();
          const startSamp = w * hopSamples;
          if (startSamp >= totalSamples) break;
          const endSamp = Math.min(startSamp + windowSamples, totalSamples);
          const slice = decoded.samples.slice(startSamp, endSamp);
          if (slice.length < SAMPLE_RATE * 0.3) continue;
          const offsetSec = startSamp / SAMPLE_RATE;

          log(
            `[whisper] window ${w + 1}/${windows} (${offsetSec.toFixed(0)}s–${(offsetSec + slice.length / SAMPLE_RATE).toFixed(0)}s)…`
          );

          // First window with auto: no language → Whisper detects
          const langArg =
            sourceLang === 'auto' && w === 0 && !detectedLang
              ? undefined
              : forcedLang || (detectedLang && detectedLang !== 'ku' ? detectedLang : forcedLang);

          const result = await transcribeChunk(slice, langArg);

          if (sourceLang === 'auto' && w === 0) {
            const dl =
              detectLangFromResult(result as WorkerResult & { language?: string }) ||
              // Heuristic: if chunks look Arabic script, mark ar; else en default from latin
              null;
            if (dl) {
              detectedLang = dl;
              forcedLang = dl === 'ku' || dl === 'ckb' ? undefined : dl;
              log(`[whisper] detected language: ${dl}`, 'ok');
            } else {
              // Infer from text script of first result
              const sample = (result.text || '') + (result.chunks || []).map((c) => c.text || '').join(' ');
              if (/[\u0600-\u06FF]/.test(sample) && !/[A-Za-z]{4,}/.test(sample)) {
                detectedLang = 'ar';
                forcedLang = 'ar';
                log('[whisper] detected script: Arabic → language=ar', 'ok');
              } else if (/[A-Za-z]/.test(sample)) {
                detectedLang = 'en';
                forcedLang = 'en';
                log('[whisper] detected script: Latin → language=en (will refine if needed)', 'ok');
              } else {
                log('[whisper] language unclear — continuing multilingual decode', 'warn');
              }
            }
          }

          const pieces = piecesFromWhisper(result, offsetSec);
          // Drop pieces that fall mostly inside the overlap region of the previous window (except first)
          for (const p of pieces) {
            if (w > 0 && p.start < offsetSec + 0.35) {
              // keep only if it extends well into this window's unique region
              if (p.end <= offsetSec + 2.5) continue;
            }
            allPieces.push(p);
          }

          log(
            `[whisper] window ${w + 1}/${windows}: ${pieces.length} timed piece(s)${
              pieces.length === 0 ? ' (silence?)' : ''
            }`,
            pieces.length === 0 ? 'warn' : 'info'
          );
          setS('transcribe', Math.round(32 + 36 * ((w + 1) / windows)));
          if (projectId) {
            await patchProject(projectId, {
              progress: Math.round(32 + 36 * ((w + 1) / windows)),
              stage: 'transcribe',
              original_lang: detectedLang || sourceLang,
            });
          }
        }

        // Sort and de-duplicate near-identical pieces
        allPieces.sort((a, b) => a.start - b.start);
        const dedupPieces: TimedPiece[] = [];
        for (const p of allPieces) {
          const prev = dedupPieces[dedupPieces.length - 1];
          if (
            prev &&
            prev.text === p.text &&
            Math.abs(prev.start - p.start) < 1.2
          ) {
            prev.end = Math.max(prev.end, p.end);
            continue;
          }
          // Overlap text merge
          if (prev && p.start < prev.end - 0.15 && p.text.startsWith(prev.text.slice(0, 12))) {
            prev.end = Math.max(prev.end, p.end);
            if (p.text.length > prev.text.length) prev.text = p.text;
            continue;
          }
          dedupPieces.push(p);
        }

        if (dedupPieces.length === 0) {
          throw new Error(
            'No speech was recognized. The audio may be silent, music-only, or too noisy — try a file with clear speech.'
          );
        }
        log(`[whisper] done — ${dedupPieces.length} timed pieces`, 'ok');

        setS('timing', 70);
        const turns = detectSpeechTurns(decoded.samples);
        log(
          `[timing] detected ${turns.length} speech turn(s)${
            diarization
              ? ' → alternating speakers (pause heuristic)'
              : ' (diarization off → single speaker)'
          }`
        );
        let segs = mergeToSubtitles(dedupPieces, turns, diarization);
        segs = refineWithPauses(segs, turns);
        log(`[timing] merged into ${segs.length} subtitle segment(s)`, 'ok');
        setS('timing', 72);
        checkCancel();

        type SegT = (typeof segs)[0] & { sorani?: string; engine?: string };
        let translated: SegT[];

        const mtSource =
          sourceLang === 'ku'
            ? 'ku'
            : detectedLang && detectedLang !== 'auto'
              ? detectedLang
              : sourceLang;

        if (sourceLang === 'ku' || mtSource === 'ku' || mtSource === 'ckb') {
          translated = segs.map((s) => ({ ...s, sorani: s.text, engine: 'passthrough' }));
          log('[translate] Sorani source — normalizing Unicode only', 'warn');
        } else {
          setS('translate', 74);
          translated = segs.map((s) => ({ ...s }));
          const batches: number[][] = [];
          for (let i = 0; i < segs.length; i += TRANSLATE_BATCH) {
            batches.push(segs.map((_, idx) => idx).slice(i, i + TRANSLATE_BATCH));
          }
          const engineCounts: Record<string, number> = {};
          for (let b = 0; b < batches.length; b++) {
            checkCancel();
            const idxs = batches[b];
            log(`[translate] batch ${b + 1}/${batches.length} (${idxs.length} segments)…`);
            const r = await fetch('/api/translate', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                texts: idxs.map((i) => segs[i].text),
                source: mtSource === 'auto' ? 'en' : mtSource,
              }),
            });
            if (!r.ok) throw new Error(`Translation service failed (HTTP ${r.status}).`);
            const data = await r.json();
            idxs.forEach((gi, j) => {
              const tr = data.translations[j];
              translated[gi] = {
                ...segs[gi],
                sorani: tr?.text || segs[gi].text,
                engine: tr?.engine || 'fallback',
              };
              engineCounts[tr?.engine || 'fallback'] =
                (engineCounts[tr?.engine || 'fallback'] || 0) + 1;
            });
            setS('translate', Math.round(74 + 18 * ((b + 1) / batches.length)));
            if (projectId) {
              await patchProject(projectId, {
                progress: Math.round(74 + 18 * ((b + 1) / batches.length)),
                stage: 'translate',
              });
            }
          }
          const summary = Object.entries(engineCounts)
            .map(([k, v]) => `${k}×${v}`)
            .join(', ');
          log(
            `[translate] done — engines used: ${summary}`,
            engineCounts.fallback ? 'warn' : 'ok'
          );
          if (engineCounts.fallback) {
            log(
              '[translate] some rows used the offline fallback (MT unreachable) — they are editable in the editor',
              'warn'
            );
          }
        }

        setS('save', 94);
        log('[db] saving subtitles…');
        const rows = translated.map((s, i) => ({
          segment_index: i,
          start_time: formatSrtTime(s.start),
          end_time: formatSrtTime(s.end),
          start_seconds: Math.round(s.start * 1000) / 1000,
          end_seconds: Math.round(s.end * 1000) / 1000,
          speaker: s.speaker,
          original_text: s.text,
          sorani_text: s.sorani || s.text,
          confidence: null,
        }));
        const saveRes = await fetch('/api/subtitles', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ project_id: created.id, segments: rows, replace: true }),
        });
        if (!saveRes.ok) throw new Error(`Failed to save subtitles (HTTP ${saveRes.status}).`);
        await patchProject(created.id, {
          status: 'completed',
          progress: 100,
          stage: 'done',
          original_lang: detectedLang || sourceLang,
        });
        log(`[db] saved ${rows.length} rows — project completed`, 'ok');
        setS('done', 100);

        const refreshed = await fetch(`/api/projects?id=${created.id}`).then((r) => r.json());
        const proj = Array.isArray(refreshed) ? refreshed[0] : refreshed;
        onDone(proj || { ...created, status: 'completed', progress: 100, stage: 'done' });
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        if (msg === 'CANCELLED') {
          log('[system] cancelled by user', 'warn');
          if (projectId) {
            await patchProject(projectId, {
              status: 'failed',
              error: 'Cancelled by user',
              stage: 'cancelled',
            });
          }
          setStage('idle');
          setProgress(0);
          setActive(false);
          return;
        }
        console.error('[pipeline]', e);
        log(`[error] ${msg}`, 'err');
        setError(msg);
        setStage('error');
        if (projectId) {
          await patchProject(projectId, { status: 'failed', error: msg, stage: 'error' });
        }
      } finally {
        setActive(false);
      }
    },
    [pushLog, ensureModel, transcribeChunk, patchProject]
  );

  const cancel = useCallback(() => {
    cancelled.current = true;
  }, []);

  const reset = useCallback(() => {
    setActive(false);
    setStage('idle');
    setProgress(0);
    setLogs([]);
    setError(null);
    setModelPct(0);
  }, []);

  return { active, stage, progress, logs, modelPct, error, run, cancel, reset };
}
