/** Audio decode → mono 16 kHz PCM + optional enhancement for Whisper. */

export const SAMPLE_RATE = 16_000;

export type DecodedAudio = {
  samples: Float32Array;
  durationSec: number;
  channels: number;
  sourceRate: number;
};

export async function decodeTo16kMono(
  file: File,
  log: (msg: string) => void
): Promise<DecodedAudio> {
  log(
    `[upload] file: ${file.name} (${(file.size / 1048576).toFixed(2)} MB, type=${file.type || 'unknown'})`
  );
  const buf = await file.arrayBuffer();
  log(
    `[audio] read ${(buf.byteLength / 1048576).toFixed(2)} MB into memory, decoding with Web Audio API…`
  );

  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AC();
  let audio: AudioBuffer;
  try {
    audio = await ctx.decodeAudioData(buf.slice(0));
  } finally {
    try {
      await ctx.close();
    } catch {
      /* ignore */
    }
  }

  const durationSec = audio.duration;
  log(
    `[audio] decoded: ${audio.numberOfChannels}ch @ ${audio.sampleRate}Hz, duration ${durationSec.toFixed(2)}s`
  );
  if (!isFinite(durationSec) || durationSec < 0.5) {
    throw new Error('Could not decode any audio from this file.');
  }
  if (durationSec > 1200) {
    throw new Error(
      `Audio is ${Math.round(durationSec / 60)} min — the in-browser pipeline supports up to 20 min.`
    );
  }

  const n = audio.length;
  const ch = audio.numberOfChannels;
  // Downmix to mono
  const mono = new Float32Array(n);
  for (let c = 0; c < ch; c++) {
    const data = audio.getChannelData(c);
    for (let i = 0; i < n; i++) mono[i] += data[i] / ch;
  }

  // Resample to 16 kHz with linear interpolation
  const targetLen = Math.max(1, Math.floor((n / audio.sampleRate) * SAMPLE_RATE));
  const samples = new Float32Array(targetLen);
  const ratio = n / targetLen;
  for (let i = 0; i < targetLen; i++) {
    const srcPos = i * ratio;
    const i0 = Math.floor(srcPos);
    const i1 = Math.min(i0 + 1, n - 1);
    const t = srcPos - i0;
    samples[i] = mono[i0] * (1 - t) + mono[i1] * t;
  }

  log(
    `[audio] resampled to 16kHz mono PCM (${targetLen.toLocaleString()} samples) — ready for Whisper`
  );
  return { samples, durationSec, channels: ch, sourceRate: audio.sampleRate };
}

/** Peak-normalize toward ~0.89 to improve STT on quiet recordings without clipping. */
export function peakNormalize(samples: Float32Array, log: (msg: string) => void): Float32Array {
  let peak = 0;
  for (let i = 0; i < samples.length; i++) {
    const a = Math.abs(samples[i]);
    if (a > peak) peak = a;
  }
  if (peak < 1e-4) {
    log('[audio] signal is near-silent, skipping normalization');
    return samples;
  }
  const gain = 0.89 / peak;
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i++) out[i] = samples[i] * gain;
  log(`[audio] peak-normalized (gain ${gain.toFixed(2)}x) for cleaner recognition`);
  return out;
}

/**
 * Light high-pass (DC / rumble removal) + soft noise gate.
 * Keeps speech intact; does not use aggressive denoise that can hurt Whisper.
 */
export function enhanceSpeech(samples: Float32Array, log: (msg: string) => void): Float32Array {
  const out = new Float32Array(samples.length);
  // One-pole high-pass ~80 Hz at 16 kHz
  const rc = 1 / (2 * Math.PI * 80);
  const dt = 1 / SAMPLE_RATE;
  const alpha = rc / (rc + dt);
  let prevX = 0;
  let prevY = 0;
  for (let i = 0; i < samples.length; i++) {
    const x = samples[i];
    const y = alpha * (prevY + x - prevX);
    prevX = x;
    prevY = y;
    out[i] = y;
  }

  // Soft gate: estimate noise floor from quietest 10% of 20ms frames, attenuate below
  const frame = Math.floor(SAMPLE_RATE * 0.02);
  const energies: number[] = [];
  for (let i = 0; i + frame <= out.length; i += frame) {
    let e = 0;
    for (let j = 0; j < frame; j++) e += out[i + j] * out[i + j];
    energies.push(Math.sqrt(e / frame));
  }
  const sorted = [...energies].sort((a, b) => a - b);
  const noiseFloor = sorted[Math.max(0, Math.floor(sorted.length * 0.1))] || 0.001;
  const thresh = Math.max(noiseFloor * 2.2, 0.004);
  for (let i = 0; i < out.length; i++) {
    const a = Math.abs(out[i]);
    if (a < thresh) out[i] *= a / thresh; // soft attenuation
  }

  log(
    `[audio] speech enhance: HPF@80Hz + soft gate (noise≈${noiseFloor.toFixed(4)}, thr=${thresh.toFixed(4)})`
  );
  return out;
}

export function meanAbsEnergy(samples: Float32Array, stride = 97): number {
  let sum = 0;
  let n = 0;
  for (let i = 0; i < samples.length; i += stride) {
    sum += Math.abs(samples[i]);
    n++;
  }
  return n ? sum / n : 0;
}
