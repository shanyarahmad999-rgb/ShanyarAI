/**
 * Natural subtitle segmentation using:
 * - Whisper chunk / word timestamps
 * - speech pauses (energy VAD)
 * - punctuation
 * - reading speed & max readable length
 */

import { SAMPLE_RATE } from './audio';

export type TimedPiece = {
  start: number;
  end: number;
  text: string;
  words?: { word: string; start: number; end: number }[];
};

export type SpeechTurn = { start: number; end: number };

export type SubtitleSeg = {
  start: number;
  end: number;
  text: string;
  speaker: string;
};

const MAX_CHARS = 48; // soft target for one readable line
const MAX_CHARS_HARD = 78;
const MAX_DURATION = 7.0;
const MIN_DURATION = 0.7;
const MAX_CPS = 22; // chars per second reading speed
const PAUSE_SPLIT = 0.45; // seconds of gap that prefers a break
const SENTENCE_END = /[.!?…؟۔:]$/;
const SOFT_BREAK = /[,;،]$/;

/** Energy VAD → speech turns (for optional speaker alternation). */
export function detectSpeechTurns(samples: Float32Array): SpeechTurn[] {
  const frame = Math.floor(SAMPLE_RATE * 0.02);
  let peak = 0;
  const rms: number[] = [];
  for (let i = 0; i < samples.length; i += frame) {
    let e = 0;
    const n = Math.min(frame, samples.length - i);
    for (let j = 0; j < n; j++) e += samples[i + j] * samples[i + j];
    const r = Math.sqrt(e / n);
    rms.push(r);
    if (r > peak) peak = r;
  }
  const thresh = Math.max(peak * 0.08, 0.015);
  const turns: SpeechTurn[] = [];
  let start: number | null = null;
  let silence = 0;
  const silenceFrames = Math.round(1 / 0.02); // 1s
  rms.forEach((r, idx) => {
    const t = (idx * frame) / SAMPLE_RATE;
    if (r >= thresh) {
      if (start === null) start = t;
      silence = 0;
    } else if (start !== null) {
      silence++;
      if (silence >= silenceFrames) {
        turns.push({ start, end: t - silence * 0.02 });
        start = null;
        silence = 0;
      }
    }
  });
  if (start !== null) turns.push({ start, end: samples.length / SAMPLE_RATE });
  return turns.filter((t) => t.end - t.start > 0.35);
}

function speakerAt(t: number, turns: SpeechTurn[], diarization: boolean): string {
  if (!diarization || turns.length === 0) return 'Speaker 1';
  const i = turns.findIndex((tr) => t >= tr.start - 0.3 && t <= tr.end + 0.6);
  return `Speaker ${((i >= 0 ? i : 0) % 2) + 1}`;
}

function cleanText(s: string): string {
  return s.replace(/\s+/g, ' ').trim();
}

/** Expand Whisper chunks into word-aware atomic pieces when word timestamps exist. */
export function expandPieces(pieces: TimedPiece[]): TimedPiece[] {
  const out: TimedPiece[] = [];
  for (const p of pieces) {
    if (p.words && p.words.length > 0) {
      // Keep original chunk but attach words; also emit word groups later
      out.push({
        start: p.start,
        end: Math.max(p.end, p.start + 0.05),
        text: cleanText(p.text),
        words: p.words
          .map((w) => ({
            word: cleanText(w.word),
            start: w.start,
            end: Math.max(w.end, w.start + 0.04),
          }))
          .filter((w) => w.word.length > 0),
      });
    } else if (cleanText(p.text)) {
      out.push({
        start: p.start,
        end: Math.max(p.end, p.start + 0.05),
        text: cleanText(p.text),
      });
    }
  }
  return out;
}

/**
 * Merge Whisper timed pieces into natural subtitle lines.
 */
export function mergeToSubtitles(
  pieces: TimedPiece[],
  turns: SpeechTurn[],
  diarization: boolean
): SubtitleSeg[] {
  const expanded = expandPieces(pieces);
  if (expanded.length === 0) return [];

  // Flatten to word stream when possible for finer control
  type Atom = { start: number; end: number; text: string };
  const atoms: Atom[] = [];
  for (const p of expanded) {
    if (p.words && p.words.length >= 2) {
      for (const w of p.words) atoms.push({ start: w.start, end: w.end, text: w.word });
    } else {
      // Split multi-word chunk by spaces but distribute time proportionally
      const words = p.text.split(/\s+/).filter(Boolean);
      if (words.length <= 1) {
        atoms.push({ start: p.start, end: p.end, text: p.text });
      } else {
        const dur = Math.max(p.end - p.start, 0.05);
        const totalChars = words.reduce((s, w) => s + w.length, 0) || 1;
        let t = p.start;
        words.forEach((w, i) => {
          const share = (w.length / totalChars) * dur;
          const end = i === words.length - 1 ? p.end : t + Math.max(share, 0.04);
          atoms.push({ start: t, end, text: w });
          t = end;
        });
      }
    }
  }

  // Sort & de-overlap
  atoms.sort((a, b) => a.start - b.start || a.end - b.end);
  for (let i = 1; i < atoms.length; i++) {
    if (atoms[i].start < atoms[i - 1].end) {
      atoms[i].start = atoms[i - 1].end;
      if (atoms[i].end <= atoms[i].start) atoms[i].end = atoms[i].start + 0.04;
    }
  }

  const segs: SubtitleSeg[] = [];
  let cur: Atom[] = [];

  const flush = () => {
    if (!cur.length) return;
    const text = cleanText(cur.map((a) => a.text).join(' '));
    if (!text) {
      cur = [];
      return;
    }
    let start = cur[0].start;
    let end = cur[cur.length - 1].end;
    if (end - start < MIN_DURATION) end = start + MIN_DURATION;
    // avoid overlapping previous
    if (segs.length) {
      const prev = segs[segs.length - 1];
      if (start < prev.end) start = prev.end;
      if (end <= start) end = start + 0.05;
    }
    segs.push({
      start: Math.round(start * 1000) / 1000,
      end: Math.round(end * 1000) / 1000,
      text,
      speaker: speakerAt(start, turns, diarization),
    });
    cur = [];
  };

  const curText = () => cleanText(cur.map((a) => a.text).join(' '));
  const curDur = () => (cur.length ? cur[cur.length - 1].end - cur[0].start : 0);

  for (let i = 0; i < atoms.length; i++) {
    const a = atoms[i];
    const gap = cur.length ? a.start - cur[cur.length - 1].end : 0;
    const nextText = cur.length ? `${curText()} ${a.text}` : a.text;
    const wouldDur = cur.length ? a.end - cur[0].start : a.end - a.start;
    const cps = nextText.length / Math.max(wouldDur, 0.2);

    const pauseBreak = gap >= PAUSE_SPLIT;
    const hardLong = nextText.length > MAX_CHARS_HARD;
    // Prefer finishing a clause before duration-splitting (avoid mid-phrase cuts)
    const atomEndsClause = SOFT_BREAK.test(a.text) || SENTENCE_END.test(a.text);
    const longTime = wouldDur > MAX_DURATION && !atomEndsClause;
    const fastRead = cps > MAX_CPS && nextText.length > 32 && !atomEndsClause;
    const sentenceBreak =
      cur.length > 0 &&
      SENTENCE_END.test(curText()) &&
      (gap > 0.12 || nextText.length > 20);

    // Prefer breaks at commas when the current line is getting long
    const commaBreak =
      cur.length > 0 &&
      SOFT_BREAK.test(curText()) &&
      (curText().length >= 22 || wouldDur >= 3.2);

    // Soft length pressure only when we have a pause or punctuation opportunity
    const softLong =
      nextText.length > MAX_CHARS &&
      (gap > 0.1 || SOFT_BREAK.test(curText()) || SENTENCE_END.test(curText()));

    if (
      cur.length &&
      (pauseBreak || hardLong || longTime || sentenceBreak || commaBreak || softLong || fastRead)
    ) {
      flush();
    }

    cur.push(a);

    // Natural break: after comma/period once the line is readable length
    if (
      (SOFT_BREAK.test(a.text) && curText().length >= 24) ||
      (SENTENCE_END.test(a.text) && curText().length >= 12)
    ) {
      flush();
      continue;
    }

    // If over hard limits, try to back-split at last soft break inside current buffer
    if (curText().length >= MAX_CHARS_HARD || curDur() >= MAX_DURATION) {
      const texts = cur.map((x) => x.text);
      let splitAt = -1;
      for (let k = texts.length - 2; k >= Math.floor(texts.length * 0.35); k--) {
        if (SOFT_BREAK.test(texts[k]) || SENTENCE_END.test(texts[k])) {
          splitAt = k;
          break;
        }
      }
      if (splitAt > 0) {
        const left = cur.slice(0, splitAt + 1);
        const right = cur.slice(splitAt + 1);
        cur = left;
        flush();
        cur = right;
      } else {
        flush();
      }
    }
  }
  flush();

  // Merge tiny orphans into neighbors when possible
  const merged: SubtitleSeg[] = [];
  for (const s of segs) {
    if (
      merged.length &&
      s.text.split(/\s+/).length <= 2 &&
      s.text.length < 12 &&
      s.start - merged[merged.length - 1].end < 0.35 &&
      (merged[merged.length - 1].text + ' ' + s.text).length <= MAX_CHARS_HARD &&
      s.end - merged[merged.length - 1].start <= MAX_DURATION + 0.5
    ) {
      const p = merged[merged.length - 1];
      p.text = cleanText(p.text + ' ' + s.text);
      p.end = s.end;
    } else {
      merged.push({ ...s });
    }
  }

  // Deduplicate identical consecutive lines
  const deduped: SubtitleSeg[] = [];
  for (const s of merged) {
    const prev = deduped[deduped.length - 1];
    if (prev && prev.text === s.text && s.start - prev.end < 0.4) {
      prev.end = Math.max(prev.end, s.end);
      continue;
    }
    if (s.end > s.start && s.text) deduped.push(s);
  }

  return deduped;
}

/**
 * Snap subtitle boundaries toward nearby silence when available (VAD turns),
 * without inventing timing.
 */
export function refineWithPauses(segs: SubtitleSeg[], turns: SpeechTurn[]): SubtitleSeg[] {
  if (!turns.length) return segs;
  return segs.map((s) => {
    // slightly tighten end if silence starts early
    let { start, end } = s;
    for (const t of turns) {
      if (t.end >= start - 0.2 && t.end <= end && end - t.end > 0.25 && t.end - start >= MIN_DURATION) {
        // if turn ends mid-subtitle, keep speech end closer
        if (end - t.end < 0.8) end = Math.max(t.end + 0.05, start + MIN_DURATION);
      }
      if (t.start <= end + 0.2 && t.start >= start && t.start - start > 0.2) {
        if (t.start - start < 0.5) start = Math.max(s.start, t.start - 0.05);
      }
    }
    if (end <= start) end = start + MIN_DURATION;
    return { ...s, start, end };
  });
}
