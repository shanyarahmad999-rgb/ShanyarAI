/** SRT helpers — UTF-8 with BOM for Kurdish players. */

export function formatSrtTime(seconds: number): string {
  const s = Math.max(0, seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  const ms = Math.floor((s % 1) * 1000);
  const p2 = (n: number) => String(n).padStart(2, '0');
  const p3 = (n: number) => String(n).padStart(3, '0');
  return `${p2(h)}:${p2(m)}:${p2(sec)},${p3(ms)}`;
}

export function parseSrtTime(t: string): number | null {
  const m = t
    .trim()
    .replace('.', ',')
    .match(/^(\d+):(\d{2}):(\d{2}),(\d{3})$/);
  if (!m) return null;
  return (
    parseInt(m[1], 10) * 3600 +
    parseInt(m[2], 10) * 60 +
    parseInt(m[3], 10) +
    parseInt(m[4], 10) / 1000
  );
}

export type SrtRow = {
  start_time: string;
  end_time: string;
  sorani_text: string;
};

export function buildSrt(rows: SrtRow[]): string {
  let out = '\uFEFF';
  rows.forEach((r, i) => {
    out += `${i + 1}\n${r.start_time} --> ${r.end_time}\n${(r.sorani_text || '').trim()}\n\n`;
  });
  return out;
}

export function downloadSrt(rows: SrtRow[], filename: string) {
  const blob = new Blob([buildSrt(rows)], { type: 'text/srt;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.srt') ? filename : `${filename}.srt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
