import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { id } = req.query;
      if (id) {
        const { data, error } = await supabase.from('projects').select('*').eq('id', id).maybeSingle();
        if (error) throw error;
        return res.status(200).json(data ? [data] : []);
      }
      const { data, error } = await supabase.from('projects').select('*').order('id', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const row = {
        title: body.title || 'Untitled project',
        original_lang: body.original_lang || 'auto',
        target_lang: body.target_lang || 'ckb',
        video_url: body.video_url || 'local',
        duration_seconds: body.duration_seconds ?? 0,
        status: body.status || 'queued',
        progress: body.progress ?? 0,
        stage: body.stage || 'queued',
        error: body.error || null,
        updated_at: new Date().toISOString(),
      };
      const { data, error } = await supabase.from('projects').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const body = req.body || {};
      const { id, ...rest } = body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = { ...rest, updated_at: new Date().toISOString() };
      delete patch.id;
      const { data, error } = await supabase.from('projects').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id } = req.body || {};
      if (!id) return res.status(400).json({ error: 'id required' });
      await supabase.from('subtitles').delete().eq('project_id', id);
      const { error } = await supabase.from('projects').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('projects API error:', err);
    res.status(500).json({ error: err.message });
  }
}
