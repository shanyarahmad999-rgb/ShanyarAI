import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { project_id, id } = req.query;
      if (id) {
        const { data, error } = await supabase.from('subtitles').select('*').eq('id', id).maybeSingle();
        if (error) throw error;
        return res.status(200).json(data);
      }
      let q = supabase.from('subtitles').select('*').order('segment_index', { ascending: true });
      if (project_id) q = q.eq('project_id', project_id);
      const { data, error } = await q;
      if (error) throw error;
      return res.status(200).json(data || []);
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      if (Array.isArray(body.segments) && body.project_id != null) {
        // Full pipeline save sets replace:true; editor add/split omits it (append only).
        if (body.replace === true) {
          await supabase.from('subtitles').delete().eq('project_id', body.project_id);
        }
        const rows = body.segments.map((s, i) => ({
          project_id: body.project_id,
          segment_index: s.segment_index ?? i,
          start_time: s.start_time,
          end_time: s.end_time,
          start_seconds: s.start_seconds,
          end_seconds: s.end_seconds,
          speaker: s.speaker || 'Speaker 1',
          original_text: s.original_text || '',
          sorani_text: s.sorani_text || '',
          confidence: s.confidence ?? null,
        }));
        if (rows.length === 0) return res.status(201).json([]);
        const { data, error } = await supabase.from('subtitles').insert(rows).select();
        if (error) throw error;
        return res.status(201).json(data);
      }
      const row = {
        project_id: body.project_id ?? null,
        segment_index: body.segment_index ?? null,
        start_time: body.start_time ?? null,
        end_time: body.end_time ?? null,
        start_seconds: body.start_seconds ?? null,
        end_seconds: body.end_seconds ?? null,
        speaker: body.speaker ?? null,
        original_text: body.original_text ?? null,
        sorani_text: body.sorani_text ?? null,
        confidence: body.confidence ?? null,
      };
      const { data, error } = await supabase.from('subtitles').insert(row).select().single();
      if (error) throw error;
      return res.status(201).json(data);
    }

    if (req.method === 'PUT') {
      const body = req.body || {};
      const { id, ...rest } = body;
      if (!id) return res.status(400).json({ error: 'id required' });
      const patch = { ...rest };
      delete patch.id;
      const { data, error } = await supabase.from('subtitles').update(patch).eq('id', id).select().single();
      if (error) throw error;
      return res.status(200).json(data);
    }

    if (req.method === 'DELETE') {
      const { id, project_id } = req.body || {};
      if (project_id != null && id == null) {
        const { error } = await supabase.from('subtitles').delete().eq('project_id', project_id);
        if (error) throw error;
        return res.status(200).json({ ok: true });
      }
      if (!id) return res.status(400).json({ error: 'id required' });
      const { error } = await supabase.from('subtitles').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('subtitles API error:', err);
    res.status(500).json({ error: err.message });
  }
}
