/**
 * Sorani (ckb) translation API.
 * Engines (in order): Google Translate (clients5) → MyMemory → labelled offline fallback.
 * Never invents fake “AI” output without marking engine.
 */

const GOOGLE_ENDPOINT = 'https://clients5.google.com/translate_a/t';
const MYMEMORY_ENDPOINT = 'https://api.mymemory.translated.net/get';

/** Map UI / Whisper codes → Google + MyMemory source codes */
const SOURCE_MAP = {
  auto: 'auto',
  en: 'en',
  ar: 'ar',
  fa: 'fa',
  tr: 'tr',
  de: 'de',
  ku: 'ckb',
  ckb: 'ckb',
  fr: 'fr',
  es: 'es',
  ru: 'ru',
  hi: 'hi',
  ur: 'ur',
  zh: 'zh-CN',
  ja: 'ja',
  ko: 'ko',
  pt: 'pt',
  it: 'it',
  nl: 'nl',
  pl: 'pl',
  id: 'id',
  ms: 'ms',
};

/** Offline phrase bank used only when live MT fails (labelled engine=fallback) */
const FALLBACK_PHRASES = [
  [/hello everyone/i, 'سڵاو لە هەمووان'],
  [/hello\b/i, 'سڵاو'],
  [/welcome back/i, 'بەخێربێنەوە'],
  [/welcome/i, 'بەخێربێن'],
  [/thank you very much/i, 'زۆر سپاس'],
  [/thank you/i, 'سوپاس'],
  [/thanks/i, 'سوپاس'],
  [/please subscribe/i, 'تکایە بەشداری بکەن'],
  [/subscribe/i, 'بەشداری بکەن'],
  [/leave a comment/i, 'کۆمێنتێک بنووسن'],
  [/artificial intelligence|\bAI\b/i, 'زیرەکی دەستکرد'],
  [/technology/i, 'تەکنەلۆژیا'],
  [/good morning/i, 'بەیانی باش'],
  [/good evening/i, 'ئێوارە باش'],
  [/good night/i, 'شەو باش'],
  [/good afternoon/i, 'نیوەڕۆ باش'],
  [/how are you/i, 'چۆنی'],
  [/see you later/i, 'دواتر دەتبینمەوە'],
  [/see you/i, 'دەتبینمەوە'],
  [/\byes\b/i, 'بەڵێ'],
  [/\bno\b/i, 'نەخێر'],
  [/\bok\b|\bokay\b/i, 'باشە'],
];

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function normalizeSorani(text) {
  if (!text) return '';
  return String(text)
    .replace(/\u200c+/g, '\u200c')
    .replace(/[ي]/g, 'ی')
    .replace(/[ك]/g, 'ک')
    .replace(/[ۀة]/g, 'ە')
    .replace(/[ؤ]/g, 'و')
    .replace(/[أإآ]/g, 'ا')
    .replace(/[ء]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function offlineFallback(text) {
  let out = text;
  let hit = false;
  for (const [re, rep] of FALLBACK_PHRASES) {
    if (re.test(out)) {
      out = out.replace(re, rep);
      hit = true;
    }
  }
  if (!hit) {
    // Keep original so the editor can fix it — never invent fake Kurdish.
    return normalizeSorani(text);
  }
  return normalizeSorani(out);
}

async function translateGoogle(text, source) {
  const sl = source === 'auto' ? 'auto' : SOURCE_MAP[source] || source || 'auto';
  const params = new URLSearchParams({
    client: 'dict-chrome-ex',
    sl,
    tl: 'ckb',
    q: text,
  });
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 12000);
  try {
    const r = await fetch(`${GOOGLE_ENDPOINT}?${params}`, {
      signal: ctrl.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        Accept: '*/*',
      },
    });
    if (!r.ok) throw new Error(`google HTTP ${r.status}`);
    const data = await r.json();
    // formats: ["text"] or [["text","src"]] or { sentences: [...] }
    let translated = '';
    if (Array.isArray(data)) {
      if (typeof data[0] === 'string') translated = data[0];
      else if (Array.isArray(data[0])) translated = data.map((x) => (Array.isArray(x) ? x[0] : x)).join('');
      else translated = String(data[0] ?? '');
    } else if (data && typeof data === 'object') {
      if (Array.isArray(data.sentences)) {
        translated = data.sentences.map((s) => s.trans || '').join('');
      } else if (typeof data.translation === 'string') {
        translated = data.translation;
      }
    }
    translated = normalizeSorani(translated);
    if (!translated || translated.toLowerCase() === text.toLowerCase()) {
      throw new Error('empty google result');
    }
    return translated;
  } finally {
    clearTimeout(t);
  }
}

async function translateMyMemory(text, source) {
  const sl = source === 'auto' ? 'en' : SOURCE_MAP[source] || source || 'en';
  // MyMemory uses ckb for Sorani Arabic script
  const pair = `${sl}|ckb`;
  const params = new URLSearchParams({ q: text.slice(0, 450), langpair: pair });
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 12000);
  try {
    const r = await fetch(`${MYMEMORY_ENDPOINT}?${params}`, { signal: ctrl.signal });
    if (!r.ok) throw new Error(`mymemory HTTP ${r.status}`);
    const data = await r.json();
    const translated = normalizeSorani(data?.responseData?.translatedText || '');
    if (!translated) throw new Error('empty mymemory');
    // Reject obvious garbage / same-language passthrough when source is Latin
    if (/^[A-Za-z0-9\s.,!?'"%-]+$/.test(translated) && /[A-Za-z]/.test(text)) {
      throw new Error('mymemory returned non-Kurdish');
    }
    return translated;
  } finally {
    clearTimeout(t);
  }
}

async function translateOne(text, source) {
  const cleaned = String(text || '').trim();
  if (!cleaned) return { text: '', engine: 'empty' };

  // Already Sorani / Arabic-script Kurdish → normalize only
  if (source === 'ku' || source === 'ckb') {
    return { text: normalizeSorani(cleaned), engine: 'passthrough' };
  }

  try {
    const t = await translateGoogle(cleaned, source);
    return { text: t, engine: 'google' };
  } catch (e1) {
    try {
      const t = await translateMyMemory(cleaned, source);
      return { text: t, engine: 'mymemory' };
    } catch (e2) {
      return { text: offlineFallback(cleaned), engine: 'fallback' };
    }
  }
}

export default async function handler(req, res) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      return res.status(200).json({
        ok: true,
        engines: ['google', 'mymemory', 'fallback'],
        target: 'ckb',
      });
    }

    if (req.method === 'POST') {
      const body = req.body || {};
      const texts = body.texts;
      if (!Array.isArray(texts) || texts.length === 0) {
        return res.status(400).json({ error: 'texts[] required' });
      }
      const source = body.source || 'auto';
      // Sequential with tiny delay to reduce rate-limit hits; batch size kept small by client
      const translations = [];
      for (let i = 0; i < texts.length; i++) {
        const result = await translateOne(texts[i], source);
        translations.push(result);
        if (i < texts.length - 1) await new Promise((r) => setTimeout(r, 80));
      }
      return res.status(200).json({ translations, target: 'ckb' });
    }

    res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('translate API error:', err);
    res.status(500).json({ error: err.message });
  }
}
